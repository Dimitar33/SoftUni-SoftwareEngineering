﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomDoublyLinkedList
{
    class DoublyLinkedList<T>
    {
       
        private ListNode<T> head;

        private ListNode<T> tail;

        public int Count { get; set; }

        public void AddFirst(T element)
        {
            if (Count == 0)
            {
                head = tail = new ListNode<T>(element);
            }
            else
            {
                var temp = new ListNode<T>(element);
                temp.Next = head;
                head.Previous = temp;
                head = temp;
            }
            Count++;
        }

        public void AddLast(T element)
        {
            if (Count == 0)
            {
                head = tail = new ListNode<T>(element);
            }
            else
            {
                var temp = new ListNode<T>(element);
                temp.Previous = tail;
                tail.Next = temp;
                tail = temp;
            }
            Count++;
        }

        public T RemoveFirst()
        {
            if (Count == 0)
            {
                throw new InvalidOperationException("The list is empty");
            }

            var first = head.Value;
            head = head.Next;

            if (Count == 1)
            {
                head = null;
                tail = null;
            }

            Count--;
            head.Previous = null;
            return first;
        }

        public T RemoveLast()
        {
            if (Count == 0)
            {
                throw new InvalidOperationException("The list is empty");
            }

            var last = tail.Value;
            tail = tail.Previous;

            if (Count == 1)
            {
                head = null;
                tail = null;
            }

            Count--;
            tail.Next = null;
            return last;
        }

        public void ForEach(Action<T> action)
        {
            var temp = head;

            while (temp != null)
            {
                action(temp.Value);
                temp = temp.Next;

            }
        }

        public T[] ToArray()
        {
            T[] array = new T[Count];
            int counter = 0;
            var temp = head;

            while (counter < array.Length)
            {
                array[counter] = temp.Value;
                temp = temp.Next;
                counter++;
            }
            return array;
        }
    }
}
