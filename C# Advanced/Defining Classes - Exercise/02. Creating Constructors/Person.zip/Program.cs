﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Person person = new Person("pesho", 21);



            Person person1 = new Person("Gosho", 21);


        }

    }
}
