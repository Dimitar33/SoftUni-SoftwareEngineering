﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.FoodShortage
{
    public class Human 
    {
        public Human(string name, string age)
        {
           
            Name = name;
            Age = age;
            
        }

        public string Name { get; set; }
        public string Age { get; set; }
   

      
    }
}
