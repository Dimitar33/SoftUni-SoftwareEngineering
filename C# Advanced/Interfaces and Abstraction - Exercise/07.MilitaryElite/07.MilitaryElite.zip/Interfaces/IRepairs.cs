﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.MilitaryElite
{
    public interface IRepairs
    {
        public string RepairName { get; set; }
        public int RepairDuration { get; set; }
    }
}
